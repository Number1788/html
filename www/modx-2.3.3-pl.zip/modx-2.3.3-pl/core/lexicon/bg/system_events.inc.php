<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Изчисти';
$_lang['error_log'] = 'Регистър на грешки';
$_lang['error_log_desc'] = 'Регистър на грешки за MODX Revolution:';
$_lang['error_log_download'] = 'Изтегли регистър на грешки  ([[+size]])';
$_lang['error_log_too_large'] = 'Регистъра на грешки в <em>[[+name]]</em> е прекалено голям, за да бъде разгледан. Можете да го изтеглите черз бутона долу.';
$_lang['system_events'] = 'Системни събития';
$_lang['priority'] = 'Приоритет';